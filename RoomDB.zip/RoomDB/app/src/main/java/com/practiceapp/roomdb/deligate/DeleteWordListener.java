package com.practiceapp.roomdb.deligate;

import com.practiceapp.roomdb.table.Word;

public interface DeleteWordListener {
    public void onDeleteWord(Word word);
}



