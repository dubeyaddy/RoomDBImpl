package com.practiceapp.roomdb.editDeligate;

import com.practiceapp.roomdb.table.Word;

public interface EditWordListener {
    public void onEditWord(Word word);
}
