package com.practiceapp.roomdb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.practiceapp.roomdb.deligate.DeleteWordListener;
import com.practiceapp.roomdb.editDeligate.EditWordListener;
import com.practiceapp.roomdb.table.Word;
import com.practiceapp.roomdb.viewHolder.WordListAdapter;
import com.practiceapp.roomdb.viewmodel.WordViewModel;

public class MainActivity extends AppCompatActivity {
    private WordViewModel mWordViewModel;
    public static final int NEW_WORD_ACTIVITY_REQUEST_CODE = 1;
    public WordListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView=findViewById(R.id.recyclerview);
        adapter= new WordListAdapter(new WordListAdapter.WordDiff(), new DeleteWordListener() {
            @Override
            public void onDeleteWord(Word word) {
                mWordViewModel.delete(word);
                adapter.notifyDataSetChanged();
            }


        });
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        mWordViewModel=new ViewModelProvider(this).get(WordViewModel.class);

        mWordViewModel.getAllWords().observe(this,words -> {
            adapter.submitList(words);
        });

        FloatingActionButton fab=findViewById(R.id.fab);
        fab.setOnClickListener(view->{
            Intent intent= new Intent(MainActivity.this,NewWordActivity.class);
            startActivityForResult(intent, NEW_WORD_ACTIVITY_REQUEST_CODE);
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        if(requestCode==NEW_WORD_ACTIVITY_REQUEST_CODE&& resultCode==RESULT_OK){
            Word word= new Word(data.getStringExtra(NewWordActivity.Extra_reply));
            mWordViewModel.insert(word);
        }else {
            Toast.makeText(
                    getApplicationContext(),
                    R.string.empty_not_saved,
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.wordmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.deleteAll){
            mWordViewModel.deleteAll();
            Toast.makeText(MainActivity.this,"Delete All selected",Toast.LENGTH_SHORT).show();
        }
        else if(item.getItemId()==R.id.test1)
        {
            Toast.makeText(MainActivity.this,"Test1 selected",Toast.LENGTH_SHORT).show();
        }
        else if (item.getItemId()==R.id.test2){

        }
        return super.onOptionsItemSelected(item);
    }
}